﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Class1
    {
        String countruCode;
        String countruName;


        public void setCoutryCode(String countryCode)
        {
            this.countruCode = countryCode;
        }

        public void setCoutryName(String countryCode)
        {
            this.countruName = countryCode;
        }
    }
}
